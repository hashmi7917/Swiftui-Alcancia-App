//
//  MainView.swift
//  Bank App
//
//  Created by hashmi syed imran on 13/01/21.
//

import SwiftUI

struct MainView: View {
    @State var showingProfile = false
    var body: some View {
        
        VStack(spacing: 20) {
            
            HStack {
                Button(action: {
                    self.showingProfile.toggle()
                }) {
                    Image(systemName: "command")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(width: 40, height: 40)
                        .background(Color(#colorLiteral(red: 0.2431372549, green: 0.5607843137, blue: 0.968627451, alpha: 1)))
                        .cornerRadius(10)
                }.sheet(isPresented: $showingProfile) {
                    ProfileView(showingProfile: .constant(false))
                }
                
                Spacer()
                
                Text("alcancia")
                    .font(Font.custom("Poppins-Bold", size: 28))
                    .foregroundColor(.white)
            }
            .padding(.horizontal, 20)
            
            Spacer()
            
            // Card View
            ScrollView(.vertical, showsIndicators: false) {
                VStack(spacing: 40) {
                    
                    CardView(tittle: "Your Alcanica", subtitle: "main account", balance: "12.537", savings: "1.746", image: "2")
                    
                    CardView(tittle: "Grandma account", subtitle: "sub-account", balance: "86.264", savings: "10.326", image: "4")
                    
                    CardView(tittle: "Martha Beltran", subtitle: "child-sub-account", balance: "12.537", savings: "1.746", image: "1")
                    
                }
            }
            .shadow(color: Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)).opacity(0.2), radius: 20, x: 0, y: 20)
            
        }
        
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}

struct CardView: View {
    var tittle: String
    var subtitle: String
    var balance: String
    var savings: String
    var image: String
    
    var body: some View {
        VStack(spacing: 40) {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text(tittle)
                        .font(.system(size: 24)).bold()
                    
                    Text(subtitle.uppercased())
                        .font(.footnote)
                        .padding(.horizontal, 5)
                }
                Spacer()
                
                Image(image)
                    .resizable()
                    .frame(width: 50, height: 50)
                    .cornerRadius(10)
            }
            .padding(.horizontal, 10)
            
            HStack {
                VStack(alignment: .leading, spacing: 10) {
                    Text("BALANCE")
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(Color(#colorLiteral(red: 0.2196078449, green: 0.007843137719, blue: 0.8549019694, alpha: 1)))
                    
                    Text("\(balance) £")
                        .font(.system(size: 22))
                        .fontWeight(.bold)
                    
                }
                .padding()
                .frame(width: 140, height: 120)
                .background(Color(#colorLiteral(red: 0.9333333333, green: 0.9450980392, blue: 1, alpha: 1)))
                .cornerRadius(26)
                
                Spacer()
                
                VStack(alignment: .leading, spacing: 10) {
                    Text("SAVINGS")
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(Color(#colorLiteral(red: 0.2196078449, green: 0.007843137719, blue: 0.8549019694, alpha: 1)))
                    
                    Text("\(savings) £")
                        .font(.system(size: 22))
                        .fontWeight(.bold)
                    
                }
                .padding()
                .frame(width: 140, height: 120)
                .background(Color(#colorLiteral(red: 0.9333333333, green: 0.9450980392, blue: 1, alpha: 1)))
                .cornerRadius(26)
            }
            
            
            
        }
        .frame(width: 300, height: 200, alignment: .top)
        .padding(25)
        .background(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
        .clipShape(RoundedRectangle(cornerRadius: 40, style: .continuous))
    }
}

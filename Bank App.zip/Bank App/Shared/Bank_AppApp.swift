//
//  Bank_AppApp.swift
//  Shared
//
//  Created by hashmi syed imran on 13/01/21.
//

import SwiftUI

@main
struct Bank_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  LaunchView.swift
//  Bank App
//
//  Created by hashmi syed imran on 13/01/21.
//

import SwiftUI

struct LaunchView: View {
    var body: some View {
        ZStack {
            Color(#colorLiteral(red: 0.2941176471, green: 0.2862745098, blue: 0.9254901961, alpha: 1))
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                Image("logo")
            }
            .offset(y: -50)
            .padding(.vertical, -50)
        }

    }
}

struct LaunchView_Previews: PreviewProvider {
    static var previews: some View {
        LaunchView()
    }
}

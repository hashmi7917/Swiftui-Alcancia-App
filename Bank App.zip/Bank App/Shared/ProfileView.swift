//
//  ProfileView.swift
//  Bank App
//
//  Created by hashmi syed imran on 13/01/21.
//

import SwiftUI

struct ProfileView: View {
    @Binding var showingProfile: Bool
    
    var body: some View {
        ZStack {
            (Color(#colorLiteral(red: 0.2941176471, green: 0.2862745098, blue: 0.9254901961, alpha: 1)))
            
            VStack(spacing: 50) {
                HStack {
                    Image(systemName: "xmark")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(width: 40, height: 40)
                        .background(Color(#colorLiteral(red: 0.2431372549, green: 0.5607843137, blue: 0.968627451, alpha: 1)))
                        .cornerRadius(15)
                        
                    
                    Spacer()
                }
                .padding(.horizontal)
                .onTapGesture {
                    self.showingProfile = false
                }
                
                HStack {
                    VStack(alignment: .leading) {
                        Text("Hello,")
                        Text("Marcos")
                    }
                    .font(Font.custom("Poppins-Bold", size: 40))
                    .foregroundColor(.white)
                    
                    Spacer()
                    
                    Image("1")
                        .resizable()
                        .frame(width: 80, height: 80)
                        .cornerRadius(25)
                        .shadow(radius: 20)
                }
                .padding(.horizontal)
                
                VStack(spacing: 20) {
                    ProfileDetail(image: "person.fill", title: "Profile Settings")
                    
                    ProfileDetail(image: "creditcard.fill", title: "Create a sub-account")
                    
                    ProfileDetail(image: "person.fill.badge.plus", title: "Invite friends")
                    
                    ProfileDetail(image: "chart.bar.doc.horizontal.fill", title: "News and updates")
                    
                    ProfileDetail(image: "info.circle.fill", title: "About Alcancia")
                    
                    ProfileDetail(image: "quote.bubble.fill", title: "Help")
                }
                
                HStack {
                    
                    Text("")
                    
                    Spacer()
                    
                    HStack {
                        Text("Log out")
                        
                        Spacer()
                        
                        Image(systemName: "square.and.arrow.up")
                            .rotationEffect(Angle(degrees: 90))
                    }
                    .frame(width: 120, height: 40)
                    .padding()
                    .padding(.horizontal)
                    .background(Color.white)
                    .cornerRadius(30)
                    
                    
                }
            }
            .padding()
        }
        .edgesIgnoringSafeArea(.all)
        
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView(showingProfile: .constant(true))
    }
}

struct ProfileDetail: View {
    var image: String
    var title: String
    
    var body: some View {
        HStack(spacing: 20) {
            Image(systemName: image)
                .font(.largeTitle)
                .frame(width: 50, height: 50)
                .aspectRatio(contentMode: .fit)
            
            Text(title)
                .font(.system(size: 24))
            
            Spacer()
            
        }
        .foregroundColor(.white)
        .padding(.horizontal)
    }
}

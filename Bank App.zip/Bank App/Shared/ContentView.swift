//
//  ContentView.swift
//  Shared
//
//  Created by hashmi syed imran on 13/01/21.
//

import SwiftUI

struct ContentView: View {
    @State var isActive:Bool = false
    
    var body: some View {
        ZStack {
            Color(#colorLiteral(red: 0.2941176471, green: 0.2862745098, blue: 0.9254901961, alpha: 1))
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                if self.isActive {
                    // 3.
                    MainView()
                } else {
                    // 4.
                    LaunchView()
                }
            }
            .onAppear {
                // 6.
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                    // 7.
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.6, blendDuration: 0.5)) {
                        self.isActive = true
                    }
                }
            }
            
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
